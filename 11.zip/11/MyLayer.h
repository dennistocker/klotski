//
//  MyLayer.h
//  11
//
//  Created by 程利 on 2018/1/15.
//  Copyright © 2018年 foundersc. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>

@interface MyLayer : CAShapeLayer

@end
