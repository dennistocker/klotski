//
//  MyNewView.h
//  11
//
//  Created by 程利 on 2018/1/15.
//  Copyright © 2018年 foundersc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyNewView : UIView

@end
