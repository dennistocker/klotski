//
//  MyNewView.m
//  11
//
//  Created by 程利 on 2018/1/15.
//  Copyright © 2018年 foundersc. All rights reserved.
//

#import "MyNewView.h"

@implementation MyNewView

- (void)drawRect:(CGRect)rect
{
    UIBezierPath *path = [UIBezierPath bezierPathWithOvalInRect:rect];

    [[UIColor blueColor] setStroke];

    [path stroke];
}

@end
