//
//  ViewController.m
//  11
//
//  Created by 程利 on 2018/1/15.
//  Copyright © 2018年 foundersc. All rights reserved.
//

#import "ViewController.h"
#import "MyView.h"
#import "MyNewView.h"
#import "HRBackgoundView.h"
#import "HRNumView.h"
#import "PriorityQueue.h"
#import "GameState.h"

@interface ViewController ()
@property (nonatomic, strong) HRNumView *currentView;
@property (nonatomic, assign) CGPoint touchPoint;
@property (nonatomic, strong) NSMutableArray *numberArray;

@property (nonatomic, strong) PriorityQueue *openNodes;
@property (nonatomic, strong) NSMutableArray *closedNodes;
@property (nonatomic, strong) GameState *desState;

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];

    CGFloat height = 304;
    CGRect rect = CGRectMake(30, 200, height, height);
    HRBackgoundView *bgView = [[HRBackgoundView alloc] initWithFrame:rect andLevel:3];
    [self.view addSubview:bgView];



    _numberArray = [[NSMutableArray alloc] init];
    for (int i = 0; i < 9; ++i) {
        [_numberArray addObject:@(i)];
    }
    [_numberArray sortUsingComparator:^NSComparisonResult(id  _Nonnull obj1, id  _Nonnull obj2) {
        NSLog(@"sorting: %@- %@", obj1, obj2);
        return (NSComparisonResult)(arc4random_uniform(3) - 1);
    }];
    for (int i = 0; i < 9; ++i) {
        NSInteger number = [_numberArray[i] integerValue];
        if (number != 0) {
            CGFloat width = (height-4)/3 -1;
            HRNumView *numView = [[HRNumView alloc] initWithFrame:CGRectMake(32+(width+1)*(i%3), 202+(width+1)*(i/3), width, width)];
            [numView setNumber:number];
            [self.view addSubview:numView];
        }
    }
    _desState = [[GameState alloc] init];
    _desState.numbers = @[ @(1), @(2), @(3), @(4), @(5), @(6), @(7), @(8), @(9), @(0) ];

    // 算法
    _openNodes = [[PriorityQueue alloc] init];
    _closedNodes = [[NSMutableArray alloc] init];

    GameState *state = [[GameState alloc] init];
    state.numbers = _numberArray;
    [_openNodes add:state];

    do {
        GameState *state = [_openNodes poll];
        [_closedNodes addObject:state];

        if ([_closedNodes containsObject:_desState]) {
            NSLog(@"finish");
            break;
        }

        NSArray *nextStates = [self getNextStates:state];
        for (GameState *nextState in nextStates) {

            if ([_closedNodes containsObject:nextState]) {
                continue;
            }
            [_openNodes add:nextState];
        }
    } while (![_openNodes isEmpty]);
}

- (NSArray *)getNextStates:(GameState *)state {
    NSLog(@"getNextStates");

    static int i = 0;
    i++;
    NSArray *numbers = @[ @(i), @(i+1) ];
    if (i ==3) {
        numbers = @[ @(1), @(2), @(3), @(4), @(5), @(6), @(7), @(8), @(9), @(0) ];
    }

    GameState *nextState = [[GameState alloc] init];
    nextState.numbers = numbers;

    return @[nextState];
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [super touchesBegan:touches withEvent:event];

    UITouch *touch = [touches anyObject];
    UIView *touchView = touch.view;
    if ([touchView isKindOfClass:[HRNumView class]]) {
        _currentView = (HRNumView *) touchView;
        _touchPoint = [touch locationInView:self.view];
    }
}

- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [super touchesMoved:touches withEvent:event];

    UITouch *touch = [touches anyObject];
    CGPoint point = [touch locationInView:self.view];

    int direction = 0; // 左上右下
    CGFloat diff;
    CGFloat diffY = point.y - _touchPoint.y;
    CGFloat diffX = point.x - _touchPoint.x;
    if (ABS(diffY) > ABS(diffX)) {
        direction = (diffY > 0) ? 3 : 1;
        diff = diffY;
    } else {
        direction = (diffX > 0) ? 2 : 0;
        diff = diffX;
    }
    NSLog(@"move direction: %@", @(direction));

    if ([self canMoveView:_currentView withDirection:direction]) {
        [self moveView:_currentView withDirection:direction offset:diff];
    }
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [super touchesEnded:touches withEvent:event];

    _currentView = nil;
}

- (void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [super touchesCancelled:touches withEvent:event];

    _currentView = nil;
}

- (BOOL)canMoveView:(HRNumView *)view withDirection:(NSInteger)direction
{
    NSInteger index = [_numberArray indexOfObject:@([view getNumber])];
    NSInteger desIndex = 0;

    switch (direction) {
        case 0:
            desIndex = index - 1;
            break;
        case 1:
            desIndex = index - 3;
            break;
        case 2:
            desIndex = index + 1;
            break;
        case 3:
            desIndex = index + 3;
            break;
        default:
            break;
    }
    return (desIndex >= 0 && desIndex < 9 && [_numberArray[desIndex] integerValue] == 0);
}

- (void)moveView:(HRNumView *)view withDirection:(NSInteger)direction offset:(CGFloat)diff
{
    NSInteger index = [_numberArray indexOfObject:@([view getNumber])];
    NSInteger desIndex = 0;

    switch (direction) {
        case 0:
            desIndex = index - 1;
            break;
        case 1:
            desIndex = index - 3;
            break;
        case 2:
            desIndex = index + 1;
            break;
        case 3:
            desIndex = index + 3;
            break;
        default:
            break;
    }
    _numberArray[desIndex] = @([view getNumber]);
    _numberArray[index] = @(0);

    CGFloat width = (302-4*2)/3;
    view.frame = CGRectMake(32+(width+2)*(desIndex%3), 202+(width+2)*(desIndex/3), width, width);
}


@end
