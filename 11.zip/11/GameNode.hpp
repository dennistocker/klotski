//
//  GameNode.hpp
//  11
//
//  Created by 程利 on 2018/1/15.
//  Copyright © 2018年 foundersc. All rights reserved.
//

#ifndef GameNode_hpp
#define GameNode_hpp

#include <stdio.h>

class GameNode {
    GameNode();
    

};
#endif /* GameNode_hpp */
